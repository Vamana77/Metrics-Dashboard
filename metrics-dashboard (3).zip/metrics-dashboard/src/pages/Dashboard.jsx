import React from "react";
import {
  PieChart, Pie, Cell, BarChart, Bar,
  XAxis, YAxis, AreaChart, Area, Tooltip, ResponsiveContainer
} from "recharts";

const pieData = [
  { name: "A", value: 400 },
  { name: "B", value: 300 },
  { name: "C", value: 300 },
];

const barData = [
  { name: "Jan", uv: 400 },
  { name: "Feb", uv: 300 },
  { name: "Mar", uv: 500 },
];

const areaData = [
  { name: "Week 1", value: 100 },
  { name: "Week 2", value: 200 },
  { name: "Week 3", value: 300 },
];

const COLORS = ["#0088FE", "#00C49F", "#FFBB28"];

export default function Dashboard() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="p-4 border rounded-xl">
        <h3 className="font-bold mb-2">Pie Chart</h3>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie data={pieData} dataKey="value" outerRadius={80}>
              {pieData.map((_, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="p-4 border rounded-xl">
        <h3 className="font-bold mb-2">Bar Chart</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={barData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="uv" fill="#8884d8" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="p-4 border rounded-xl">
        <h3 className="font-bold mb-2">Area Chart</h3>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={areaData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Area dataKey="value" stroke="#82ca9d" fill="#82ca9d" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
