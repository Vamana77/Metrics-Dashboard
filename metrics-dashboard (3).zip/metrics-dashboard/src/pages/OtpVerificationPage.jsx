import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/OtpVerificationPage.css";

const OtpVerificationPage = () => {
  const [otp, setOtp] = useState("");
  const navigate = useNavigate();

  const handleVerify = (e) => {
    e.preventDefault();

    if (otp === "123456") {
      alert("OTP Verified Successfully!");
      navigate("/login");
    } else {
      alert("Invalid OTP. Please try again.");
    }
  };

  return (
    <div className="otp-container">
      <form className="otp-form" onSubmit={handleVerify}>
        <h2>OTP Verification</h2>
        <input
          type="text"
          placeholder="Enter OTP"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          required
        />
        <button type="submit">Verify</button>
      </form>
    </div>
  );
};

export default OtpVerificationPage;
