import React from "react";
import "./Home.css";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="home-wrapper">
      <section className="hero">
        <h1 className="hero-title">Real-Time Metrics Dashboard</h1>
        <p className="hero-subtitle">
          Track system performance live across all microservices with rich visual insights.
        </p>
        <div className="hero-buttons">
          <Link to="/login" className="hero-btn primary">Get Started</Link>
          <Link to="/signup" className="hero-btn secondary">Create Account</Link>
          <Link to="/forgot-password" className="hero-btn forgot">Forgot Password?</Link>
        </div>
      </section>

      <section className="features">
        <div className="feature-card">
          <h3>🚀 Kafka Streaming</h3>
          <p>Push metrics in real time using event-driven Kafka pipelines.</p>
        </div>
        <div className="feature-card">
          <h3>⚙️ Reactive Spring API</h3>
          <p>Low-latency REST API with Spring WebFlux for async metric access.</p>
        </div>
        <div className="feature-card">
          <h3>🧠 Redis for Speed</h3>
          <p>Instant access to aggregated time-series data using Redis.</p>
        </div>
        <div className="feature-card">
          <h3>📈 Live Dashboards</h3>
          <p>Real-time graphs and metrics powered by React & Chart.js.</p>
        </div>
      </section>
    </div>
  );
};

export default Home;
